<?php
ob_start();
session_start();
include('db_config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</head>

<body style="background:white;">
  <form class=" container-fluid mt-5 pt-5 pb-5 bg-white rounded-3 w-50  mx-auto d-block shadow-lg" action="" method="POST">
    <h2 class="fw-light text-center bg-light">LOGIN</h2>
    <div class="col-md-6 col-sm-12 m-1 p-2  mx-auto d-block">
      <label for="exampleInputEmail1" class="fw-light col-sm-2 col-form-label col-form-label-sm">Username</label>
      <input type="email" class="form-control form-control-sm" id="exampleInputEmail1" aria-describedby="emailHelp" name="username" autocomplete="current-username">
    </div>
    <div class="col-md-6 col-sm-12 m-1 p-2 mx-auto d-block">
      <label for="exampleInputPassword1" class="fw-light col-sm-2 col-form-label col-form-label-sm">Password</label>
      <input type="password" class="form-control form-control-sm" id="exampleInputPassword1" name="password" autocomplete="current-password">
    </div>
    <div class="col-12 d-grid gap-2 d-md-flex justify-content-md-center mt-2 ">
      <button type="submit" name="submit" value="login" class="btn btn-dark">Log In</button>
    </div>

    <?php
    if (isset($_SESSION['login'])) {
      echo $_SESSION['login'];
      unset($_SESSION['login']);
    }

    if (isset($_SESSION['add'])) {
      echo $_SESSION['add'];
      unset($_SESSION['add']);
    }

    if (isset($_SESSION['no-login-message'])) {
      echo $_SESSION['no-login-message'];
      unset($_SESSION['no-login-message']);
    }
    ?>
  </form>
</body>

</html>


<?php
if (isset($_POST['submit'])) {

  $username = $_POST['username'];
  $password = $_POST['password'];
  $sanitized_userid = mysqli_real_escape_string($conn, $username);

  $sanitized_password = mysqli_real_escape_string($conn, $password);

  $sql = "SELECT * FROM tbl_admin WHERE username='$sanitized_userid' AND password='$sanitized_password'";
  $res = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($res);
  $count = mysqli_num_rows($res);
  $user_type = $row['user_type'];
  if ($count == 1) {
    $_SESSION['login'] = "<div class='alert alert-success mt-3'>Login Successful!</div>";
    $_SESSION['user'] = $sanitized_userid;
    if ($user_type == "admin")
    {
      $_SESSION['user_type']="admin";
      header('location:index.php');
    }
    else{
      $_SESSION['user_type']="employee";
      header('location:index_employee.php');
    }
    exit();
  } else {
    $_SESSION['login'] = "<div class='alert alert-danger mt-3'>Login Unsuccessful! Please Enter Proper Details.</div>";
    header("location:login.php");
    exit();
  }
}

?>