<?php
include 'partials/login-check.php';
include 'db_config.php';

if($_SESSION['user_type']=="employee")
{
$id = $_SESSION['user'];
$result = $conn->query("SELECT * FROM employees WHERE email='$id'");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>

<body>
  <h1 class="p-4 fw-light text-center bg-light">Employee Details</h1><br>
  <?php
  if (isset($_SESSION['success_leave'])) {
    echo $_SESSION['success_leave'];
    unset($_SESSION['success_leave']);
  }
  ?>
  <div class="container">
    <form method="" action="">
      <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="name">Name:</label>
          <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['name']; ?>" readonly>
        </div>

        <div class="form-group col-md-6">
          <label for="phone">Phone:</label>
          <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $row['phone_number']; ?>" readonly>
        </div>

      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="email">Email:</label>
          <input type="email" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>" readonly>
        </div>
        <div class="form-group col-md-6">
          <label for="salary">Salary (in Rs.):</label>
          <input type="text" class="form-control" id="salary" name="salary" value="<?php echo $row['salary']; ?>" readonly>
        </div>

      </div>


      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="position">Designation:</label>
          <input type="text" class="form-control" id="position" name="position" value="<?php echo $row['position']; ?>" readonly>
        </div>
        <div class="form-group col-md-6">
          <label for="date">Joining Date:</label>
          <input type="date" class="form-control" id="date" name="date" value="<?php echo $row['joining_date']; ?>" readonly>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-sm-2 mb-2">
            <a href="request_leave.php" >
              <button type="button" class="btn btn-success btn-block btn-sm">Request For Leave</button>
            </a>
          </div>
          <div class="col-sm-2">
            <a href="logout.php">
              <button type="button" class="btn btn-info btn-block btn-sm">Logout</button>
            </a>
          </div>
          <div class="col-sm-2">
            <a href="leave_list.php">
              <button type="button" class="btn btn-dark btn-block btn-sm">View your Leaves</button>
            </a>
          </div>
        </div>
      </div>

    </form>
  </div><br>

</body>

</html>
<?php
}
else{
  header("location:logout.php");
}
?>