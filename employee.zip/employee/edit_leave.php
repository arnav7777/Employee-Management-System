<?php
ob_start();
include 'db_config.php';
include 'partials/navbar-admin.php';
if ($_SESSION['user_type'] == "admin") {
  $id = $_GET['id'];
  $result = $conn->query("SELECT * FROM leave_requests WHERE id='$id'");
  $row = $result->fetch_assoc();

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = htmlspecialchars($_POST['id']);
    $status = $_POST['status'];

    $conn->query("UPDATE `leave_requests` SET `status`='$status' WHERE id=$id");


    $_SESSION['success_leave'] = "<div class='alert alert-success alert-dismissible fade show' role='alert'>
      <strong>Leave Request Updated!</strong>
      <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
    </div>";

    header('Location: leave_management.php');
    exit;
  }
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Request</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  </head>

  <body>
    <h1 class="p-4 fw-light text-center bg-light">Leave Request</h1><br>
    <div class="container">
      <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="employee_id">Employee ID:</label>
            <input type="text" class="form-control" id="employee_id" name="employee_id" value="<?php echo $row['employee_id']; ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label for="email">Email:</label>
            <input type="text" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['employee_name']; ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label for="position">Designation:</label>
            <input type="text" class="form-control" id="position" name="position" value="<?php echo $row['position']; ?>" readonly>
          </div>

          <div class="form-group col-md-6">
            <label for="start_date">Leave from:<span style="color: red;">*</span></label>
            <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $row['start_date']; ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label for="end_date">Leave till:<span style="color: red;">*</span></label>
            <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $row['end_date']; ?>" readonly>
          </div>

        </div>

        <div class="form-row">

          <div class="form-group col-md-6">
            <label for="reason">Reason:<span style="color: red;">*</span></label>
            <textarea class="form-control" placeholder="<?php echo $row['comments']; ?>" id="reason" name="reason" style="height: 100px" readonly></textarea>
          </div>
          <div class="form-row">

            <div class="form-group col-md-12">
              <label for="status">Status:<span style="color: red;">*</span></label>
              <select class="form-select" aria-label="Default select example" name="status" id="status">
                <option value="Pending" selected>Pending</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>

          </div>
        </div>
        <div class="container">
          <div class="row">
            <div class="col-sm-2 mb-2">
              <button type="submit" class="btn btn-success btn-block btn-sm">Update</button>
            </div>
          </div>
        </div>

      </form>
    </div><br>

  </body>

  </html>
<?php
} else {
  header("location:logout.php");
}
?>