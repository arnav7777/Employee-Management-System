<?php
require 'vendor/autoload.php'; // Include Composer autoloader
include 'db_config.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Fetch data from the database
$result = $conn->query("SELECT * FROM leave_requests ORDER BY request_date DESC");

if ($result->num_rows > 0) {
  // Create a new Spreadsheet object
  $spreadsheet = new Spreadsheet();
  $sheet = $spreadsheet->getActiveSheet();

  // Add headers to the Excel file
  $sheet->setCellValue('A1', 'Employee ID');
  $sheet->setCellValue('B1', 'Employee Name');
  $sheet->setCellValue('C1', 'Email');
  $sheet->setCellValue('D1', 'Leave from');
  $sheet->setCellValue('E1', 'Leave till');
  $sheet->setCellValue('F1', 'Reason');
  $sheet->setCellValue('G1', 'Status');
  $sheet->setCellValue('H1', 'Date Requested on');

  // Fill data in the Excel file
  $rowIndex = 2;
  while ($row = $result->fetch_assoc()) {
    $sheet->setCellValue('A' . $rowIndex, $row['employee_id']);
    $sheet->setCellValue('B' . $rowIndex, $row['employee_name']);
    $sheet->setCellValue('C' . $rowIndex, $row['email']);
    $sheet->setCellValue('D' . $rowIndex, $row['start_date']);
    $sheet->setCellValue('E' . $rowIndex, $row['end_date']);
    $sheet->setCellValue('F' . $rowIndex, $row['comments']);
    $sheet->setCellValue('G' . $rowIndex, $row['status']);
    $sheet->setCellValue('H' . $rowIndex, $row['request_date']);
    $rowIndex++;
  }

  // Clear any previous output
  ob_clean();

  // Set the headers for download
  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  header('Content-Disposition: attachment;filename="leave_requests.xlsx"');
  header('Cache-Control: max-age=0');

  // Create a writer and send the output to the browser
  $writer = new Xlsx($spreadsheet);
  $writer->save('php://output');
  exit;
} else {
  echo "No data to export.";
}
