<?php
ob_start();
include 'db_config.php';
include 'partials/navbar-admin.php';
if ($_SESSION['user_type'] == "admin") {
  $id = $_SESSION['user'];
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Management</title>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css"> <!-- Correct URL for CSS -->

    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>

  </head>

  <body>
    <h1 class="p-4 fw-light text-center bg-light">Manage Employees Leaves</h1>
    <div class="text-center">
      <a href="download_excel.php" class="btn btn-primary">Download as Excel</a>
    </div>
    <?php
    $result = $conn->query("SELECT * FROM leave_requests ORDER BY request_date DESC");

    if ($result->num_rows > 0) {
      $totalCount = $result->num_rows; ?>
      <br>
      <h4 class="text-center">Total Leaves Requests: <?php echo $totalCount; ?></h4><br>
      <div class="table-responsive p-2 m-2">
        <table class="table table-bordered table-hover" id="employeeTable">
          <thead>
            <tr>
              <th>Employee ID</th>
              <th>Email</th>
              <th>Name</th>
              <th>Leave from</th>
              <th>Leave till</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Date Requested on</th>
              <th>Update Status</th>
            </tr>
          </thead>
          <tbody>

          <?php
          while ($row = $result->fetch_assoc()) {
            $date = new DateTime($row['request_date']);
            $formattedDate = $date->format('d-M-Y');
            echo "<tr>
                    <td>{$row['employee_id']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['employee_name']}</td>
                    <td>{$row['start_date']}</td>
                    <td>{$row['end_date']}</td>
                    <td>{$row['comments']}</td>
                    <td>{$row['status']}</td>
                    <td>{$row['request_date']}</td>
                    <td>
                    <a class='btn btn-warning btn-block' href='edit_leave.php?id={$row['id']}'>Update Status</a>
                    </td>
                  </tr>";
          }
        } else {
          echo "<p class='text-center'>NO LEAVES TILL NOW!</p>";
        }
          ?>
          </tbody>
        </table>
      </div>
      <!-- Include moment.js from CDN -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

      <!-- Initialize DataTables -->
      <script>
        $(document).ready(function() {
          $('#employeeTable').DataTable({
            order: [
              [4, 'desc'] // Sort by the first column (Employee ID) in descending order 
            ],
          });
        });
      </script>


  </body>

  </html>
<?php
} else {
  header("location:logout.php");
}
?>