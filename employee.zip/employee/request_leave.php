<?php
include 'partials/login-check.php';
include 'db_config.php';

if ($_SESSION['user_type'] == "employee") {
  $id = $_SESSION['user'];
  $result = $conn->query("SELECT * FROM employees WHERE email='$id'");
  $row = $result->fetch_assoc();

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = htmlspecialchars($_POST['id']);
    $employee_id = htmlspecialchars($_POST['employee_id']);
    $name = htmlspecialchars($_POST['name']);
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $reason = $_POST['reason'];
    $email = $_POST['email'];
    $position = $_POST['position'];

    $conn->query("INSERT INTO `leave_requests`(`employee_id`,`email`, `employee_name`, `start_date`, `end_date`,`position`,`comments`) VALUES ('$employee_id','$email','$name','$start_date','$end_date','$position','$reason')");


    $_SESSION['success_leave'] = "<div class='alert alert-success alert-dismissible fade show' role='alert'>
      <strong>Leave Request Sent!</strong>
      <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
    </div>";

    header('Location: index_employee.php');
    exit;
  }
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Leave</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  </head>

  <body>
    <h1 class="p-4 fw-light text-center bg-light">Request Leave</h1><br>
    <div class="container">
      <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="employee_id">Employee ID:</label>
            <input type="text" class="form-control" id="employee_id" name="employee_id" value="<?php echo $row['employee_id']; ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label for="email">Email:</label>
            <input type="text" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['name']; ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label for="position">Designation:</label>
            <input type="text" class="form-control" id="position" name="position" value="<?php echo $row['position']; ?>" readonly>
          </div>

          <div class="form-group col-md-6">
            <label for="start_date">Leave from:<span style="color: red;">*</span></label>
            <input type="date" class="form-control" id="start_date" name="start_date" required>
          </div>
          <div class="form-group col-md-6">
            <label for="end_date">Leave till:<span style="color: red;">*</span></label>
            <input type="date" class="form-control" id="end_date" name="end_date" required>
          </div>

        </div>

        <div class="form-row">

          <div class="form-group col-md-6">
            <label for="reason">Reason:<span style="color: red;">*</span></label>
            <textarea class="form-control" placeholder="Leave a reason here" id="reason" name="reason" style="height: 100px"></textarea>
          </div>

        </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-sm-2 mb-2">
          <button type="submit" class="btn btn-success btn-block btn-sm">Request For Leave</button>
        </div>
      </div>
    </div>

    </form>
    </div><br>

  </body>

  </html>
<?php
} else {
  header("location:logout.php");
}
?>