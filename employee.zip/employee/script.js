$("#example").DataTable({
  responsive: true,
});