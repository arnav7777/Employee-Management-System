<?php
session_start();

if (!isset($_SESSION['user'])) {
    $_SESSION['no-login-message'] = "<div class='alert alert-danger mt-3'>Login to Access Admin Panel!</div>";
    header('location:login.php');
    exit(); // Make sure to exit after the redirection to prevent further execution.
}
?>
